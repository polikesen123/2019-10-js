var Girls = document.querySelector('.Girls');
var lol = document.querySelector('.lol');
var Judi = document.querySelector('.Judi');
var crossFire = document.querySelector('.crossFire');
var kingGlory = document.querySelector('.king-glory');
var Genting = document.querySelector('.Genting');
var Secondary = document.querySelector('.Secondary');
var CompetitiveG = document.querySelector('.CompetitiveG');
var networkG = document.querySelector('.networkG');
var LivingG = document.querySelector('.LivingG');
var phoneG = document.querySelector('.phoneG');
var Blizzard = document.querySelector('.Girls');
var Entertainment = document.querySelector('.Entertainment');
var TechEdu = document.querySelector('.Tech-edu');
var lis = document.querySelectorAll('.left-side li')
var $lis = $(lis);
console.log($lis)
var aside = document.querySelector('.left-side');
var flag = false;
window.onscroll = function () {
    this.showSide(this.Girls);
    let scrT = document.body.scrollTop || document.documentElement.scrollTop;
    for (let i = 0; i < lis.length; i++) {
        let t = utils.offset(lis[i]).t; //元素到body的偏移量
        let h = lis[i].clientHeight;
        if ((t - scrT <= 100) ) {
            console.log(666)
            $lis.eq(i).addClass('current').siblings().removeClass('current');
        }
    }
}

function showSide(ele) {
    let scrT = document.body.scrollTop || document.documentElement.scrollTop; //卷去的高度
    // console.log(scrT)
    // let wH = utils.winH().h; //一屏幕的高度
    let t = utils.offset(ele).t; //元素到body的偏移量
    // console.log(t)
    // let h = ele.clientHeight;
    if (t - scrT <= 100) {
        // ele.flag = true;
        aside.style.display = 'block';
        // console.log(666)
    } else {
        aside.style.display = 'none';
    }
}

function allChange() {
    lis.forEach((item, index) => {
        changeLi(item, index)
    })

}


function changeLi(ele, index) {

}